var searchData=
[
  ['parentdir_0',['parentDir',['../d2/d5a/interface_seaf_deleted_file_folder_item.html#adbfdc74da41ac45c85f6a664ba50b9e9',1,'SeafDeletedFileFolderItem']]],
  ['path_1',['path',['../d3/d35/protocol_seaf_sync_item_protocol-p.html#a03a037c4b543326c269bddd4c50b88bb',1,'SeafSyncItemProtocol-p::path'],['../da/db6/protocol_seaf_recovery_item-p.html#acce22d53c9df16dbb6c5ae653606d571',1,'SeafRecoveryItem-p::path()']]],
  ['planfilterstrategy_2',['PlanFilterStrategy',['../dc/d84/interface_plan_filter_strategy.html',1,'']]],
  ['planname_3',['planName',['../dd/d8c/interface_seaf_plan_user.html#af6e5dc1452534c086472d4f57112a5a1',1,'SeafPlanUser']]],
  ['presentviewcontroller_3aanimated_3acompletion_3a_4',['presentViewController:animated:completion:',['../df/dfb/interface_seaf_u_i_bridge.html#aecea42a8cca7dd818d8793625794c962',1,'SeafUIBridge']]]
];
