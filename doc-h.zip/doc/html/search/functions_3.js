var searchData=
[
  ['date_3aisolderthan_3a_0',['date:isOlderThan:',['../dc/d38/interface_seaf_sync_utils.html#ad06fb07513884337aceb6e74fc248b4a',1,'SeafSyncUtils']]],
  ['date_3aispreviousthan_3a_1',['date:isPreviousThan:',['../dc/d38/interface_seaf_sync_utils.html#a89b78cf398b10a3c96cb3b417b71acae',1,'SeafSyncUtils']]],
  ['deleteddatetime_2',['deletedDateTime',['../da/db6/protocol_seaf_recovery_item-p.html#ad057169402214c9013e90842e62f022a',1,'SeafRecoveryItem-p']]]
];
